Kelompok BukaGL
Ariel Miki Abraham : 1606836383 (50%)
Fersandi Pratama : 1506724505 (50%)

Untuk menjalankan program harap gunakan http server karena ada texture gambar.


1. Robot : bisa diputar putar, dan ada animasi rotasi 
2. Ular/Kereta : setiap rangkaian bisa dibelok belokan
Control: kiri-kanan untuk memutar robot